There are two code files in this folder.

To run the code, you have to install the dependencies as follows:

open3d
numpy
pyntcloud
pandas

After installing these dependencies, you can run each file directly. It will generate the plots. 